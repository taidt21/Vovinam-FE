import type { GioiTinh } from './common';

export type AthleteStatus = 'cho_duyet' | 'da_duyet' | 'da_khoa';

export interface Athlete {
  id: string;
  maVdv: string;
  hoTen: string;
  ngaySinh: string;
  gioiTinh: GioiTinh;
  teamId: string;
  canNang?: number; // chỉ đối kháng cần
  trangThai: AthleteStatus;
}

export interface Registration {
  id: string;
  athleteId: string;
  eventId: string;
}