/** @format */

export default function NoiDungBocTham() {
  return <h1>Nội dung & bốc thăm</h1>;
}
