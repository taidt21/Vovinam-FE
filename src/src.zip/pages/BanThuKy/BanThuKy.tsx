/** @format */

export default function BanThuKy() {
  return <h1>Bàn thư ký</h1>;
}
