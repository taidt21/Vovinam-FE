/** @format */

export default function KetQua() {
  return <h1>Kết quả & báo cáo</h1>;
}
