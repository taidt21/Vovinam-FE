/** @format */

export default function DoanVaVDV() {
  return <h1>Đoàn & VĐV</h1>;
}
