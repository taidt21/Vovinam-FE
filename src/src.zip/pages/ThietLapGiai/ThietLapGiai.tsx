/** @format */

export default function ThietLapGiai() {
  return <h1>Thiết lập giải</h1>;
}
